
/* ANIKOUS PREMIUM MIDI ENGINE */
(()=>{const S={a:null,i:null,notes:new Set()},$=id=>document.getElementById(id);
const stat=(t,on=false)=>{let s=$("midiStatus"),p=$("midiProPill");if(s)s.textContent=t;if(p){p.classList.toggle("online",on);p.querySelector("span").textContent=on?"ONLINE":"OFFLINE"}};
const sock=()=>{try{return window.socket||(typeof socket!=="undefined"?socket:null)}catch(_){return null}};
function hi(n,on){document.querySelectorAll("[data-midi-note='"+n+"']").forEach(x=>x.classList.toggle("midi-active",on));let m=$("midiNoteMonitor");if(m)m.textContent=on?"NOTE "+n+" • LIVE":"READY"}
function event(e){let d=e.data||[];if(d.length<2)return;let st=d[0]&240,n=d[1],v=d[2]||0,on=st===144&&v>0,off=st===128||(st===144&&v===0);if(!on&&!off)return;on?S.notes.add(n):S.notes.delete(n);hi(n,on);let s=sock();if(s&&s.emit)s.emit("midi-event",{type:on?"noteon":"noteoff",note:n,velocity:v,channel:(d[0]&15)+1})}
function attach(i){if(S.i)S.i.onmidimessage=null;S.i=i||null;if(!i){$("midiDeviceName").textContent="Not connected";stat("No MIDI input detected. Check USB-C / OTG connection.");return}i.onmidimessage=event;$("midiDeviceName").textContent=i.name||"USB MIDI Keyboard";stat("MIDI keyboard connected — ready for class.",true)}
function refresh(){if(!S.a)return;let q=$("midiDeviceSelect"),a=Array.from(S.a.inputs.values());q.innerHTML="";if(!a.length){q.innerHTML="<option>No MIDI device detected</option>";attach(null);return}a.forEach(i=>{let o=document.createElement("option");o.value=i.id;o.textContent=i.name||"MIDI Input";q.appendChild(o)});q.value=a[0].id;attach(a[0]);q.onchange=()=>attach(S.a.inputs.get(q.value))}
async function connect(){if(!navigator.requestMIDIAccess){stat("Web MIDI is not available in this browser.");return}try{S.a=await navigator.requestMIDIAccess({sysex:false});S.a.onstatechange=refresh;refresh();if(!S.a.inputs.size)stat("USB MIDI device not detected. Use a data-capable USB-C cable.");}catch(e){stat("MIDI permission/access failed. Please allow MIDI access.")}}
function panic(){S.notes.forEach(n=>hi(n,false));S.notes.clear();try{S.i&&S.i.send([176,123,0]);S.i&&S.i.send([176,120,0])}catch(_){}let s=sock();if(s&&s.emit)s.emit("midi-event",{type:"panic"});$("midiNoteMonitor").textContent="ALL NOTES STOPPED"}
addEventListener("load",()=>{$("connectMidiBtn").onclick=connect;$("midiRefreshBtn").onclick=()=>S.a?refresh():connect();$("midiPanicBtn").onclick=panic;stat("Ready — connect your USB MIDI keyboard.")})
})()
