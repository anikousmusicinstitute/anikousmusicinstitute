
/* ANIKOUS PRO MIDI STUDIO UI */
(() => {
  const S={access:null,input:null,notes:new Set(),ready:false};
  const $=id=>document.getElementById(id);
  const status=(t,ok=false)=>{
    const x=$("midiStatus"); if(x)x.textContent=t;
    const p=$("midiProPill"); if(p){p.textContent=ok?"ONLINE":"OFFLINE";p.classList.toggle("online",ok)}
  };
  const socketGet=()=>{try{return window.socket||(typeof socket!=="undefined"?socket:null)}catch(_){return null}};

  function note(n,on){
    document.querySelectorAll("[data-midi-note='"+n+"']").forEach(k=>k.classList.toggle("midi-active",on));
    const m=$("midiNoteMonitor"); if(m)m.textContent=on?"Note "+n+" • LIVE":"Ready";
  }
  function msg(e){
    const d=e.data||[]; if(d.length<2)return;
    const st=d[0]&240,n=d[1],v=d[2]||0;
    const on=st===144&&v>0,off=st===128||(st===144&&v===0);
    if(!on&&!off)return;
    if(on)S.notes.add(n);else S.notes.delete(n);
    note(n,on);
    const s=socketGet(); if(s&&s.emit)s.emit("midi-event",{type:on?"noteon":"noteoff",note:n,velocity:v,channel:(d[0]&15)+1});
  }
  function attach(i){
    if(S.input)S.input.onmidimessage=null;
    S.input=i||null;
    if(!i){S.ready=false;status("MIDI Keyboard Not Connected");$("midiDeviceName").textContent="Not connected";return}
    i.onmidimessage=msg;S.ready=true;
    $("midiDeviceName").textContent=i.name||"USB MIDI";
    status("MIDI keyboard connected and ready.",true);
  }
  function refresh(){
    if(!S.access)return;
    const sel=$("midiDeviceSelect"), inputs=Array.from(S.access.inputs.values());
    sel.innerHTML="";
    if(!inputs.length){
      sel.innerHTML="<option>No MIDI device detected</option>";
      attach(null);return;
    }
    inputs.forEach(i=>{const o=document.createElement("option");o.value=i.id;o.textContent=i.name||"MIDI Input";sel.appendChild(o)});
    attach(inputs[0]);sel.value=inputs[0].id;
    sel.onchange=()=>attach(S.access.inputs.get(sel.value));
  }
  async function connect(){
    if(!navigator.requestMIDIAccess){status("This browser does not provide Web MIDI.");return}
    try{
      S.access=await navigator.requestMIDIAccess({sysex:false});
      S.access.onstatechange=refresh;
      refresh();
      if(!S.access.inputs.size)status("No USB MIDI device detected. Check the USB-C data connection.");
    }catch(e){status("MIDI access was denied or unavailable.");}
  }
  function panic(){
    S.notes.forEach(n=>note(n,false));S.notes.clear();
    try{if(S.input){S.input.send([176,123,0]);S.input.send([176,120,0])}}catch(_){}
    const s=socketGet();if(s&&s.emit)s.emit("midi-event",{type:"panic"});
    const m=$("midiNoteMonitor");if(m)m.textContent="All notes stopped";
  }
  window.addEventListener("load",()=>{
    $("connectMidiBtn").onclick=connect;
    $("midiRefreshBtn").onclick=()=>S.access?refresh():connect();
    $("midiPanicBtn").onclick=panic;
    status("Ready — connect your USB MIDI keyboard.");
  });
})();
