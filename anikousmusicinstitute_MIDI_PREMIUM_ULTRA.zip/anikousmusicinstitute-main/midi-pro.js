
/* ANIKOUS MIDI MORE UPDATE
   Diagnostics + reconnect + note monitor + panic/all-notes-off.
*/
(() => {
  const state={access:null,input:null,notes:new Set(),connected:false};

  function el(id){return document.getElementById(id)}
  function status(t,good=false){
    const x=el("midiStatus");
    if(x){x.textContent=t;x.style.color=good?"#39d98a":""}
  }
  function detail(t){const x=el("midiDeviceName");if(x)x.textContent=t}

  function updateNote(note,on){
    document.querySelectorAll("[data-midi-note='"+note+"'], .piano-key").forEach(k=>{
      if(k.dataset.note===String(note)) k.classList.toggle("midi-active",on);
    });
    const monitor=el("midiNoteMonitor");
    if(monitor) monitor.textContent=on?("Playing: MIDI "+note):"Ready";
  }

  function sendSocket(msg){
    try{
      const s=window.socket || (typeof socket!=="undefined"?socket:null);
      if(s && s.emit) s.emit("midi-event",msg);
    }catch(_){}
  }

  function onMessage(e){
    const d=e.data||[];
    if(d.length<2)return;
    const st=d[0]&0xf0, note=d[1], vel=d[2]||0;
    const on=st===0x90&&vel>0;
    const off=st===0x80||(st===0x90&&vel===0);
    if(!on&&!off)return;
    if(on)state.notes.add(note); else state.notes.delete(note);
    updateNote(note,on);
    sendSocket({type:on?"noteon":"noteoff",note,velocity:vel,channel:(d[0]&15)+1});
  }

  function attach(input){
    if(state.input)state.input.onmidimessage=null;
    state.input=input||null;
    if(!input){state.connected=false;status("MIDI Keyboard Not Connected");detail("No MIDI input");return}
    input.onmidimessage=onMessage;
    state.connected=true;
    status("MIDI Connected: "+(input.name||"USB MIDI"),true);
    detail(input.name||"USB MIDI");
  }

  function refresh(){
    if(!state.access)return;
    const sel=el("midiDeviceSelect");
    const inputs=Array.from(state.access.inputs.values());
    if(sel){
      sel.innerHTML="";
      if(!inputs.length){
        const o=document.createElement("option");
        o.textContent="No MIDI input detected";o.value="";sel.appendChild(o);
        attach(null);return;
      }
      inputs.forEach(i=>{
        const o=document.createElement("option");
        o.value=i.id;o.textContent=i.name||"MIDI Input";sel.appendChild(o);
      });
      const chosen=inputs.find(i=>i.id===sel.value)||inputs[0];
      sel.value=chosen.id;
      attach(chosen);
      sel.onchange=()=>attach(state.access.inputs.get(sel.value));
    }
  }

  async function connect(){
    if(!navigator.requestMIDIAccess){
      status("Web MIDI not supported");
      detail("Try supported Chrome/Edge environment");
      return;
    }
    try{
      state.access=await navigator.requestMIDIAccess({sysex:false});
      state.access.onstatechange=refresh;
      refresh();
      if(!Array.from(state.access.inputs.values()).length){
        status("USB MIDI device not detected");
        detail("Check USB-C data/OTG connection");
      }
    }catch(e){
      status("MIDI permission failed");
      detail(e.message||"Permission denied");
    }
  }

  function panic(){
    state.notes.forEach(n=>updateNote(n,false));
    state.notes.clear();
    if(state.input){
      try{state.input.send([0xB0,123,0]);state.input.send([0xB0,120,0]);}catch(_){}
    }
    sendSocket({type:"panic"});
    const m=el("midiNoteMonitor");if(m)m.textContent="All notes stopped";
  }

  function setup(){
    const b=el("connectMidiBtn");
    if(b){b.textContent="🔌 Connect / Refresh MIDI";b.onclick=connect}
    const p=el("midiPanicBtn");if(p)p.onclick=panic;
    status("MIDI Keyboard Not Connected");
    detail("Waiting for USB MIDI");
  }

  window.addEventListener("load",setup);
  window.AnikousMIDIPro={connect,refresh,panic};
})();
