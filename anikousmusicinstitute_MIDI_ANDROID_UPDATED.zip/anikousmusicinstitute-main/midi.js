
/* ANIKOUS MIDI Keyboard Module
   Web MIDI + live key display + Socket.IO broadcast
*/
(() => {
  "use strict";

  const MIDI_STATE = {
    access: null,
    input: null,
    enabled: false
  };

  function midiStatus(text, ok=false) {
    const el = document.getElementById("midiStatus");
    if (el) {
      el.textContent = text;
      el.classList.toggle("midi-ok", !!ok);
    }
  }

  function noteName(note) {
    const names = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
    return names[note % 12] + (Math.floor(note / 12) - 1);
  }

  function highlightMidiKey(note, on) {
    document.querySelectorAll(`[data-midi-note="${note}"]`).forEach(k => {
      k.classList.toggle("midi-active", !!on);
    });
    document.querySelectorAll(".piano-key").forEach(k => {
      const n = Number(k.dataset.note);
      if (Number.isFinite(n) && n === note) k.classList.toggle("midi-active", !!on);
    });
  }

  function broadcast(msg) {
    try {
      if (window.socket && typeof window.socket.emit === "function") {
        window.socket.emit("midi-event", msg);
      } else if (typeof socket !== "undefined" && socket && typeof socket.emit === "function") {
        socket.emit("midi-event", msg);
      }
    } catch (_) {}
  }

  function handleMidiMessage(event) {
    const d = event.data || [];
    if (d.length < 2) return;

    const status = d[0] & 0xF0;
    const note = d[1];
    const velocity = d[2] || 0;
    const type = status === 0x90 && velocity > 0 ? "noteon" :
                 (status === 0x80 || (status === 0x90 && velocity === 0) ? "noteoff" : null);

    if (!type) return;

    highlightMidiKey(note, type === "noteon");

    const payload = {
      type,
      note,
      velocity,
      noteName: noteName(note),
      channel: (d[0] & 0x0F) + 1,
      time: Date.now()
    };

    broadcast(payload);

    const ev = new CustomEvent("anikous-midi", { detail: payload });
    window.dispatchEvent(ev);
  }

  function selectInput(input) {
    if (MIDI_STATE.input) MIDI_STATE.input.onmidimessage = null;
    MIDI_STATE.input = input || null;

    if (!input) {
      midiStatus("No MIDI keyboard selected");
      return;
    }

    input.onmidimessage = handleMidiMessage;
    midiStatus("Connected: " + input.name, true);
    const name = document.getElementById("midiDeviceName");
    if (name) name.textContent = input.name || "MIDI Keyboard";
  }

  function refreshInputs() {
    const select = document.getElementById("midiDeviceSelect");
    if (!select || !MIDI_STATE.access) return;

    const previous = select.value;
    select.innerHTML = "";

    const inputs = Array.from(MIDI_STATE.access.inputs.values());
    if (!inputs.length) {
      const opt = document.createElement("option");
      opt.textContent = "No MIDI input found";
      opt.value = "";
      select.appendChild(opt);
      selectInput(null);
      return;
    }

    inputs.forEach(input => {
      const opt = document.createElement("option");
      opt.value = input.id;
      opt.textContent = input.name || "MIDI Input";
      select.appendChild(opt);
    });

    const chosen = inputs.find(x => x.id === previous) || inputs[0];
    select.value = chosen.id;
    selectInput(chosen);
  }

  async function connectMIDI() {
    if (!navigator.requestMIDIAccess) {
      midiStatus("Web MIDI not supported in this browser");
      alert("MIDI is not supported in this browser. Try Chrome/Edge on a computer.");
      return;
    }

    try {
      MIDI_STATE.access = await navigator.requestMIDIAccess({ sysex: false });
      MIDI_STATE.enabled = true;
      MIDI_STATE.access.onstatechange = refreshInputs;
      refreshInputs();
    } catch (err) {
      console.error("MIDI access error:", err);
      midiStatus("MIDI permission denied / unavailable");
      alert("MIDI access was not allowed. Please allow MIDI access and reconnect the keyboard.");
    }
  }

  function setupUI() {
    const select = document.getElementById("midiDeviceSelect");
    if (select) select.addEventListener("change", () => {
      const input = MIDI_STATE.access && MIDI_STATE.access.inputs.get(select.value);
      selectInput(input);
    });

    const btn = document.getElementById("connectMidiBtn");
    if (btn) btn.addEventListener("click", connectMIDI);

    midiStatus("MIDI not connected");
  }

  // Receive MIDI from teacher/other participant via Socket.IO.
  window.addEventListener("load", () => {
    setupUI();

    try {
      const s = window.socket || (typeof socket !== "undefined" ? socket : null);
      if (s && typeof s.on === "function") {
        s.on("midi-event", msg => {
          if (!msg || typeof msg.note !== "number") return;
          highlightMidiKey(msg.note, msg.type === "noteon");
          window.dispatchEvent(new CustomEvent("anikous-midi-remote", {detail: msg}));
        });
      }
    } catch (_) {}
  });

  window.AnikousMIDI = {
    connect: connectMIDI,
    refresh: refreshInputs,
    getInput: () => MIDI_STATE.input
  };
})();
