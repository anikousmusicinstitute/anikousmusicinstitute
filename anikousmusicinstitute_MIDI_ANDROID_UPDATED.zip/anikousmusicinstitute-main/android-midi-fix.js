
/* ANIKOUS Android USB-MIDI diagnostics
   Web MIDI is used when the browser exposes navigator.requestMIDIAccess.
   This module never reports "connected" unless an actual MIDI input is present.
*/
(() => {
  function setStatus(msg, good) {
    const s = document.getElementById("midiStatus");
    if (s) {
      s.textContent = msg;
      s.style.color = good ? "#39d98a" : "";
    }
  }

  function setDetails(msg) {
    const e = document.getElementById("midiDeviceName");
    if (e) e.textContent = msg;
  }

  function listInputs(access) {
    const select = document.getElementById("midiDeviceSelect");
    if (!select) return [];
    select.innerHTML = "";
    const inputs = Array.from(access.inputs.values());

    if (!inputs.length) {
      const o = document.createElement("option");
      o.value = "";
      o.textContent = "No USB MIDI device detected";
      select.appendChild(o);
      setStatus("MIDI Keyboard Not Connected", false);
      setDetails("Phone/browser did not expose a MIDI input");
      return [];
    }

    inputs.forEach((input, i) => {
      const o = document.createElement("option");
      o.value = input.id;
      o.textContent = input.name || ("MIDI Input " + (i + 1));
      select.appendChild(o);
    });
    return inputs;
  }

  async function connectAndroidMIDI() {
    if (!("requestMIDIAccess" in navigator)) {
      setStatus("Web MIDI not supported", false);
      setDetails("Use a browser/device with Web MIDI support");
      alert("This Android browser does not provide Web MIDI. The USB-C connection may be fine, but this browser cannot read the MIDI device.");
      return;
    }

    try {
      const access = await navigator.requestMIDIAccess({sysex:false});
      window.anikousMidiAccess = access;

      const inputs = listInputs(access);
      if (!inputs.length) return;

      const select = document.getElementById("midiDeviceSelect");
      const attach = input => {
        if (!input) return;
        input.onmidimessage = e => {
          const d = e.data || [];
          if (d.length < 2) return;
          const status = d[0] & 0xf0;
          const note = d[1];
          const velocity = d[2] || 0;
          const on = status === 0x90 && velocity > 0;
          const off = status === 0x80 || (status === 0x90 && velocity === 0);
          if (!on && !off) return;

          document.dispatchEvent(new CustomEvent("anikous-midi", {
            detail: {
              type: on ? "noteon" : "noteoff",
              note, velocity,
              channel: (d[0] & 15) + 1
            }
          }));

          // Use the existing Socket.IO connection if present.
          try {
            const s = window.socket || (typeof socket !== "undefined" ? socket : null);
            if (s && s.emit) {
              s.emit("midi-event", {
                type: on ? "noteon" : "noteoff",
                note, velocity,
                channel: (d[0] & 15) + 1
              });
            }
          } catch (_) {}
        };
        setStatus("MIDI Connected: " + (input.name || "USB MIDI"), true);
        setDetails(input.name || "USB MIDI Keyboard");
      };

      const selected = inputs[0];
      if (select) {
        select.value = selected.id;
        select.onchange = () => {
          const input = access.inputs.get(select.value);
          attach(input);
        };
      }
      attach(selected);

      access.onstatechange = () => {
        const now = listInputs(access);
        if (now.length) attach(now[0]);
      };
    } catch (e) {
      console.error(e);
      setStatus("MIDI permission/access failed", false);
      setDetails(e.message || "USB MIDI access failed");
    }
  }

  window.addEventListener("load", () => {
    const b = document.getElementById("connectMidiBtn");
    if (b) {
      b.textContent = "🔌 Connect USB MIDI";
      b.onclick = connectAndroidMIDI;
    }
    setStatus("MIDI Keyboard Not Connected", false);
  });

  window.AnikousAndroidMIDI = { connect: connectAndroidMIDI };
})();
