ANIKOUS Music Institute - MIDI Keyboard Update

1. Connect the Arturia MIDI keyboard before opening the class page.
2. Use Chrome or Edge on a computer for Web MIDI.
3. Open the class page and click "Connect MIDI Keyboard".
4. Select the Arturia MIDI input from the dropdown.
5. Play a key. The matching piano key should highlight.
6. MIDI events are also emitted through Socket.IO as "midi-event" when socket.io is available.

IMPORTANT:
- Web MIDI support depends on the browser/device.
- Android browsers may not expose Web MIDI even when the keyboard is connected through USB OTG.
- Existing video/camera code is not intentionally replaced by this MIDI module.
